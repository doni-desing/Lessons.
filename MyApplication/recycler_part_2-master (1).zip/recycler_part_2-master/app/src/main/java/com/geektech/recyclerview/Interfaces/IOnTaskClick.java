package com.geektech.recyclerview.Interfaces;

import com.geektech.recyclerview.Models.Task;

public interface IOnTaskClick {
    void openTask(Task task);
}
